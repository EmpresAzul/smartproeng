#!/bin/bash
# Script de inicialização do SmartProEng

echo "Iniciando SmartProEng..."

# Verifica se o Node.js está instalado
if ! command -v node &> /dev/null
then
    echo "Node.js não encontrado. Por favor, instale o Node.js versão 18 ou superior."
    exit 1
fi

# Verifica se o pnpm está instalado
if ! command -v pnpm &> /dev/null
then
    echo "pnpm não encontrado. Instalando pnpm..."
    npm install -g pnpm
fi

# Instala as dependências se node_modules não existir
if [ ! -d "node_modules" ]; then
    echo "Instalando dependências..."
    pnpm install --prod
fi

# Inicia o servidor
echo "Iniciando servidor..."
NODE_ENV=production node dist/index.js
