﻿// SmartProEng Platform Config
window.__PLATFORM_CONFIG__ = {
  apiUrl: window.location.origin,
  version: '1.0.0',
  environment: 'production'
};
