<?php
/**
 * SmartProEng - Server Starter via Web
 * Acesse este arquivo para iniciar o servidor: /start_server.php
 */

header('Content-Type: text/html; charset=utf-8');

$port = 3000;
$errors = [];
$success = false;

// Verificar se o servidor já está rodando
function checkServer($port) {
    $connection = @fsockopen('localhost', $port, $errno, $errstr, 1);
    if (is_resource($connection)) {
        fclose($connection);
        return true;
    }
    return false;
}

if (checkServer($port)) {
    $success = true;
    $message = "✅ Servidor já está rodando na porta $port!";
} else {
    // Tentar iniciar o servidor
    $commands = [
        "cd " . __DIR__ . " && nohup node dist/index.js > server.log 2>&1 & echo $!",
        "cd " . __DIR__ . "; nohup node dist/index.js > server.log 2>&1 & echo $!",
        "nohup node " . __DIR__ . "/dist/index.js > " . __DIR__ . "/server.log 2>&1 & echo $!",
    ];
    
    foreach ($commands as $cmd) {
        $output = @shell_exec($cmd);
        if ($output !== null && trim($output) !== '') {
            sleep(2); // Aguardar 2 segundos
            if (checkServer($port)) {
                $success = true;
                $message = "✅ Servidor iniciado com sucesso! PID: " . trim($output);
                break;
            }
        }
    }
    
    if (!$success) {
        $errors[] = "Não foi possível iniciar o servidor automaticamente.";
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartProEng - Iniciar Servidor</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            border-radius: 20px;
            padding: 3rem;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        
        h1 {
            color: #667eea;
            margin-bottom: 1.5rem;
            font-size: 2rem;
        }
        
        .success {
            background: #10b981;
            color: white;
            padding: 1.5rem;
            border-radius: 10px;
            margin: 1rem 0;
            font-weight: 600;
        }
        
        .error {
            background: #ef4444;
            color: white;
            padding: 1.5rem;
            border-radius: 10px;
            margin: 1rem 0;
        }
        
        .info {
            background: #f3f4f6;
            padding: 1.5rem;
            border-radius: 10px;
            margin: 1rem 0;
        }
        
        .info h3 {
            margin-bottom: 1rem;
            color: #374151;
        }
        
        .info pre {
            background: #1f2937;
            color: #10b981;
            padding: 1rem;
            border-radius: 8px;
            overflow-x: auto;
            font-size: 0.9rem;
        }
        
        .buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        button, a.button {
            flex: 1;
            padding: 1rem;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            transition: transform 0.2s;
        }
        
        button:hover, a.button:hover {
            transform: translateY(-2px);
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-secondary {
            background: #10b981;
            color: white;
        }
        
        .status {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }
        
        .status.online {
            background: #10b981;
            box-shadow: 0 0 10px #10b981;
        }
        
        .status.offline {
            background: #ef4444;
        }
        
        .log-section {
            margin-top: 2rem;
        }
        
        .log-content {
            background: #1f2937;
            color: #a3e635;
            padding: 1rem;
            border-radius: 8px;
            max-height: 300px;
            overflow-y: auto;
            font-family: 'Courier New', monospace;
            font-size: 0.85rem;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 SmartProEng - Gerenciador de Servidor</h1>
        
        <?php if ($success): ?>
            <div class="success">
                <span class="status online"></span>
                <?php echo $message; ?>
            </div>
            <div class="buttons">
                <a href="/" class="button btn-secondary">Acessar Site</a>
                <button onclick="location.reload()" class="button btn-primary">Atualizar Status</button>
            </div>
        <?php else: ?>
            <div class="error">
                <span class="status offline"></span>
                Servidor offline - Não foi possível iniciar automaticamente
            </div>
            
            <div class="info">
                <h3>📋 Iniciar Manualmente via SSH</h3>
                <p><strong>Conecte via SSH e execute:</strong></p>
                <pre>cd ~/public_html/napoleon
chmod +x start.sh
./start.sh</pre>
                
                <p style="margin-top: 1rem;"><strong>Ou use PM2:</strong></p>
                <pre>cd ~/public_html/napoleon
npm install -g pm2
pm2 start dist/index.js --name smartproeng
pm2 save</pre>
            </div>
            
            <div class="buttons">
                <button onclick="location.reload()" class="button btn-primary">Tentar Novamente</button>
            </div>
        <?php endif; ?>
        
        <?php if (file_exists('server.log')): ?>
        <div class="log-section">
            <h3>📄 Logs do Servidor</h3>
            <div class="log-content">
<?php echo htmlspecialchars(file_get_contents('server.log')); ?>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="info" style="margin-top: 2rem;">
            <h3>ℹ️ Informações</h3>
            <p><strong>Porta:</strong> <?php echo $port; ?></p>
            <p><strong>PHP Version:</strong> <?php echo PHP_VERSION; ?></p>
            <p><strong>Diretório:</strong> <?php echo __DIR__; ?></p>
            <p><strong>shell_exec disponível:</strong> <?php echo function_exists('shell_exec') && !in_array('shell_exec', array_map('trim', explode(',', ini_get('disable_functions')))) ? '✅ Sim' : '❌ Não (desabilitado pelo hosting)'; ?></p>
        </div>
    </div>
</body>
</html>
