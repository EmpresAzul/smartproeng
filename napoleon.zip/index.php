<?php
/**
 * SmartProEng - Auto-start Script
 * Este arquivo inicia automaticamente o servidor Node.js
 */

// Configurações
$nodeCommand = 'node dist/index.js';
$port = 3000;
$logFile = 'server.log';

// Função para verificar se o servidor está rodando
function isServerRunning($port) {
    $connection = @fsockopen('localhost', $port, $errno, $errstr, 1);
    if (is_resource($connection)) {
        fclose($connection);
        return true;
    }
    return false;
}

// Função para iniciar o servidor
function startServer($nodeCommand, $logFile) {
    $output = shell_exec("cd " . __DIR__ . " && nohup $nodeCommand > $logFile 2>&1 & echo $!");
    return trim($output);
}

// Verificar se o servidor já está rodando
if (isServerRunning($port)) {
    // Servidor está rodando, redirecionar para a aplicação
    header('Location: /dist/public/index.html');
    exit;
}

// Tentar iniciar o servidor
$pid = startServer($nodeCommand, $logFile);

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="5">
    <title>Iniciando SmartProEng...</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .container {
            text-align: center;
            padding: 3rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            animation: fadeIn 0.5s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            font-weight: 700;
        }
        
        .logo {
            font-size: 4rem;
            margin-bottom: 1rem;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        p {
            font-size: 1.1rem;
            margin: 1rem 0;
            opacity: 0.95;
        }
        
        .loader {
            margin: 2rem auto;
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-top: 4px solid white;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .info {
            background: rgba(255, 255, 255, 0.15);
            padding: 1.5rem;
            border-radius: 12px;
            margin-top: 2rem;
            font-size: 0.95rem;
            text-align: left;
        }
        
        .info strong {
            display: block;
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }
        
        .countdown {
            font-size: 2rem;
            font-weight: 700;
            color: #fbbf24;
            margin: 1rem 0;
        }
        
        .status {
            display: inline-block;
            padding: 0.5rem 1rem;
            background: rgba(34, 197, 94, 0.3);
            border-radius: 20px;
            margin-top: 1rem;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">🚀</div>
        <h1>SmartProEng</h1>
        <p>Iniciando o servidor...</p>
        <div class="loader"></div>
        <div class="countdown" id="countdown">5</div>
        <p>Aguarde enquanto preparamos tudo para você</p>
        <div class="status">
            ✓ Servidor em inicialização
        </div>
        <div class="info">
            <strong>O que está acontecendo?</strong>
            <p>• Verificando ambiente Node.js<br>
               • Iniciando servidor na porta <?php echo $port; ?><br>
               • Carregando aplicação React<br>
               • Você será redirecionado automaticamente</p>
        </div>
    </div>
    
    <script>
        let seconds = 5;
        const countdownEl = document.getElementById('countdown');
        
        const interval = setInterval(() => {
            seconds--;
            countdownEl.textContent = seconds;
            if (seconds <= 0) {
                clearInterval(interval);
                countdownEl.textContent = '✓';
                window.location.reload();
            }
        }, 1000);
        
        // Tentar verificar o servidor a cada segundo
        const checkServer = setInterval(async () => {
            try {
                const response = await fetch('/api/health');
                if (response.ok) {
                    clearInterval(checkServer);
                    clearInterval(interval);
                    window.location.href = '/dist/public/index.html';
                }
            } catch (e) {
                // Servidor ainda não está pronto
            }
        }, 1000);
    </script>
</body>
</html>
