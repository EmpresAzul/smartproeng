# SmartProEng - Guia de Deploy

## Requisitos do Servidor

- Node.js 18 ou superior
- pnpm (será instalado automaticamente se não estiver presente)
- Acesso SSH ao servidor
- Porta 3000 disponível (ou outra configurada no .env)

## Instruções de Deploy

### 1. Fazer Upload do Arquivo

Faça upload do arquivo `napoleon.zip` para o diretório `public_html` do seu servidor:

```bash
# Via FTP/SFTP ou painel de controle do hosting
# Descompacte o arquivo napoleon.zip no diretório public_html
```

### 2. Conectar via SSH e Navegar até o Diretório

```bash
cd ~/public_html/napoleon
```

### 3. Instalar Dependências

```bash
# Se você tem pnpm instalado:
pnpm install --prod

# Se não tem pnpm:
npm install -g pnpm
pnpm install --prod
```

### 4. Configurar Variáveis de Ambiente

Edite o arquivo `.env` se necessário:

```bash
nano .env
```

Variáveis disponíveis:
- `NODE_ENV=production` (já configurado)
- `PORT=3000` (altere se necessário)

### 5. Iniciar o Servidor

#### Opção A: Usando o script de inicialização

```bash
chmod +x start.sh
./start.sh
```

#### Opção B: Diretamente com Node.js

```bash
NODE_ENV=production node dist/index.js
```

#### Opção C: Usando PM2 (Recomendado para produção)

```bash
# Instalar PM2
npm install -g pm2

# Iniciar aplicação
pm2 start dist/index.js --name smartproeng

# Salvar configuração
pm2 save

# Configurar para iniciar no boot
pm2 startup
```

### 6. Configurar Proxy Reverso (Apache/Nginx)

#### Apache (.htaccess)

Crie ou edite o arquivo `.htaccess` no diretório `public_html`:

```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ http://localhost:3000/$1 [P,L]
```

#### Nginx

Adicione ao seu arquivo de configuração:

```nginx
location / {
    proxy_pass http://localhost:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
}
```

### 7. Verificar Status

```bash
# Via PM2
pm2 status

# Via curl
curl http://localhost:3000/api/health
```

Deve retornar: `{"status":"ok"}`

## Estrutura de Arquivos

```
napoleon/
├── dist/                  # Código compilado
│   ├── index.js          # Servidor principal
│   └── public/           # Arquivos estáticos
├── node_modules/         # Dependências (após instalação)
├── package.json          # Configuração do projeto
├── pnpm-lock.yaml        # Lock file das dependências
├── .env                  # Variáveis de ambiente
├── start.sh              # Script de inicialização
└── README_DEPLOY.md      # Este arquivo

```

## Troubleshooting

### Porta já em uso

```bash
# Encontrar processo usando a porta 3000
lsof -i :3000

# Matar processo
kill -9 <PID>
```

### Erro de permissões

```bash
# Dar permissões corretas aos arquivos
chmod -R 755 napoleon/
chmod +x start.sh
```

### Logs do PM2

```bash
pm2 logs smartproeng
```

## Acesso

Após o deploy completo, o site estará disponível em:
- **URL**: https://smartproeng.spweb.digital

## Suporte

Para questões ou problemas, entre em contato com o desenvolvedor.
